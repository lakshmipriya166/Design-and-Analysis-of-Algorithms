# -*- coding: utf-8 -*-
"""
Created on Thu Mar 12 17:52:25 2020

@author: Lakshmi Priya
"""

from itertools import permutations

def goal_test(s, graph):
    s=(0,)+s;
    s=s+(0,);
    n=len(graph)
    for i in range(1, n):
        if(graph[s[i-1]][s[i]]!=1 or graph[s[i]][s[(i+1)%n]]!=1):
            return False;
    return True;
        
def hamiltonian_circuits(graph, vertex):
    n=len(graph)
    print("\nHamiltonian circuits in the graph using permutation approach:\n")
    for s in list(permutations(range(1,n))):
        if(goal_test(s, graph)):
            yield(s)

     
def hamiltonian_circuits_prudent(graph, vertex):
    n=len(graph)
    
    adjVertices=dict()
    for i in range(len(graph)):
        lst=[]
        for j in range(len(graph[0])):
            if(graph[i][j]):
                lst+=[j]
        adjVertices[i]=lst
    
    def is_safe(s):
        if (len(s)==1):
            return True
        elif(len(s)==n):
            if(graph[s[n-1]][0]):
                return True
        elif(graph[s[len(s)-1]][s[len(s)-2]]):
            return True
        return False

    def solve(s):
        for adj in adjVertices[s[-1]]:
            if(adj not in s):
                if is_safe(s+(adj,)):
                    s+=(adj,)
                    solve(s)
                s=s[:-1]
        if (len(s)==n):
            for i in s:
                print(vertex[i], end=" -> ")
            print(vertex[0])

    print("\nHamiltonian circuits in the graph using prudent approach:\n")
    s=(0,)
    solve(s)

      
graph=[[0, 1, 1, 1, 0, 1, 0],
       [1, 0, 0, 1, 1, 0, 1],
       [1, 0, 0, 0, 0, 1, 0],
       [1, 1, 0, 0, 0, 1, 1],
       [0, 1, 0, 0, 0, 0, 1],
       [1, 0, 1, 1, 0, 0, 1],
       [0, 1, 0, 1, 1, 1, 0]
      ]

vertex=["A", "B", "C", "D", "E", "F", "G"]

for s in hamiltonian_circuits(graph, vertex):
    print(vertex[0], end=" -> ")
    for i in s:
        print(vertex[i], end=" -> ")
    print(vertex[0])


hamiltonian_circuits_prudent(graph, vertex)

'''
SOLUTION:
Hamiltonian circuits in the graph using permutation approach:

A -> B -> E -> G -> D -> F -> C -> A
A -> C -> F -> D -> G -> E -> B -> A
A -> C -> F -> G -> E -> B -> D -> A
A -> D -> B -> E -> G -> F -> C -> A

Hamiltonian circuits in the graph using prudent approach:

A -> B -> E -> G -> D -> F -> C -> A
A -> C -> F -> D -> G -> E -> B -> A
A -> C -> F -> G -> E -> B -> D -> A
A -> D -> B -> E -> G -> F -> C -> A
'''