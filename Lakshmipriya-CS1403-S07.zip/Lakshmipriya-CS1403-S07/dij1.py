# -*- coding: utf-8 -*-
"""
Created on Wed Feb  5 15:24:24 2020

@author: Lakshmi Priya
"""
import math

class Node:
	def __init__(self, vertex, dist):
		self.vertex = vertex
		self.dist = dist


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node(-1, -math.inf))   #sentinel for heap set
	return heap

heapindex=[]

def decreaseKey(heap, node):  
	i=heapindex[node.vertex]
    
	heap[i].vertex=node.vertex
	heap[i].dist=node.dist
    
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].dist < heap[parent].dist):
			heapindex[i]=parent
			heapindex[parent]=i
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2
    

def increaseKey(heap, node):
	i=heapindex[node.vertex]

	heap[i].vertex=node.vertex
	heap[i].dist=node.dist

	while(2*i <= len(heap)-2):
		child=2*i
		if(heap[child].dist > heap[child+1].dist):
			child += 1
		if(heap[i].dist > heap[child].dist):
			heapindex[i]=child
			heapindex[child]=i
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=2*i

        
def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	heapindex[node.vertex]=len(heap)-1
	decreaseKey(heap, node)
    
def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
		heapindex[len(heap)-1]=-1
		return heap.pop()
	heap[1]=heap.pop()
	heapindex[heap[1].vertex]=1
	increaseKey(heap, heap[1])
	return minval


def dijkstra(n, startnode, graph, vertex):
    #[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]
	heap = buildheap();
    
	INFINITY = math.inf
    
	'''    
	for adjVertices in graph[startnode][3]:     
		graph[adjVertices[0]][0] = adjVertices[1]
		graph[adjVertices[0]][1] = startnode
	'''
        
	insertheap(heap, Node(startnode, 0))
        
	graph[startnode][0]=0             #set distance of startnode
	graph[startnode][2]=1             #set startnode as known 
	
	nextnode=-1
    
	while(len(heap)>1):
		mindistance=INFINITY   
		while(len(heap)>1):                 #find unvisited node with min distance
			minNode = deletemin(heap)
			nextnode = minNode.vertex
			mindistance = minNode.dist
            
			if(graph[nextnode][2]==0):
				break
        
		graph[nextnode][2]=1               #set nextnode as known
        
		for adj in graph[nextnode][3]:     #check and update distance of adjacent nodes of nextnode
			index=adj[0]
			cost=adj[1]
			if(graph[index][2]==0):
				if(mindistance+cost < graph[index][0]):
					graph[index][0]=mindistance+cost
					graph[index][1]=nextnode
				insertheap(heap, Node(index, graph[index][0])) #insert unknown adjacent node into heap
     
	print("Graph data: ")                
	print("[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]")

	for i in graph:
		print(i)

      
	for i in range(n):	            #print shortest path from startnode to all other nodes
		if(i!=startnode):
			print("\n\nDistance of node ",vertex[i], " : ", graph[i][0])
			print("Path                 : ",vertex[i], end="")		
			j=i
			while(j!=startnode):			
				j=graph[j][1]
				print(" <- ", vertex[j], end="")




heap=buildheap()

INF=math.inf
n=12
vertex = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]

#[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]
graph = [   [INF, -1, 0, [ [1, 3], [2, 5], [3, 4]          ]   ] ,   #a
            [INF, -1, 0, [ [0, 3], [4, 3], [5, 6]          ]   ] ,   #b         
            [INF, -1, 0, [ [0, 5], [3, 2], [6, 4]          ]   ] ,   #c         
            [INF, -1, 0, [ [0, 4], [2, 2], [4, 1], [7, 5]  ]   ] ,   #d         
            [INF, -1, 0, [ [1, 3], [3, 1], [5, 2], [8, 4]  ]   ] ,   #e         
            [INF, -1, 0, [ [1, 6], [4, 2], [9, 5]          ]   ] ,   #f
            [INF, -1, 0, [ [2, 4], [7, 3], [10, 6]         ]   ] ,   #g
            [INF, -1, 0, [ [3, 5], [6, 3], [8, 6], [10, 7] ]   ] ,   #h         
            [INF, -1, 0, [ [4, 4], [7, 6], [9, 3], [11, 5] ]   ] ,   #i         
            [INF, -1, 0, [ [5, 5], [8, 3], [11, 9]         ]   ] ,   #j         
            [INF, -1, 0, [ [6, 6], [7, 7], [11, 8]         ]   ] ,   #k         
            [INF, -1, 0, [ [8, 5], [9, 9], [10, 8]         ]   ]     #l
        ]

for i in range(n):
    heapindex.append(-1)
    
startnode = 0

print("Startnode: ", vertex[startnode])

dijkstra(n, startnode, graph, vertex)

'''
graph=[ [0, 3, 5, 4, 0, 0, 0, 0, 0, 0, 0, 0], 
		[3, 0, 0, 0, 3, 6, 0, 0, 0, 0, 0, 0], 
		[5, 0, 0, 2, 0, 0, 4, 0, 0, 0, 0, 0], 
		[4, 0, 2, 0, 1, 0, 0, 5, 0, 0, 0, 0], 
		[0, 3, 0, 1, 0, 2, 0, 0, 4, 0, 0, 0], 
		[0, 6, 0, 0, 2, 0, 0, 0, 0, 5, 0, 0], 
		[0, 0, 4, 0, 0, 0, 0, 3, 0, 0, 6, 0], 
		[0, 0, 0, 5, 0, 0, 3, 0, 6, 0, 7, 0], 
		[0, 0, 0, 0, 4, 0, 0, 6, 0, 3, 0, 5], 
		[0, 0, 0, 0, 0, 5, 0, 0, 3, 0, 0, 9], 
		[0, 0, 0, 0, 0, 0, 6, 7, 0, 0, 0, 8], 
		[0, 0, 0, 0, 0, 0, 0, 0, 5, 9, 8, 0]  ]

OUTPUT:
Startnode:  a
Graph data: 
[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]
[0, -1, 1, [[1, 3], [2, 5], [3, 4]]]
[3, 0, 1, [[0, 3], [4, 3], [5, 6]]]
[5, 0, 1, [[0, 5], [3, 2], [6, 4]]]
[4, 0, 1, [[0, 4], [2, 2], [4, 1], [7, 5]]]
[5, 3, 1, [[1, 3], [3, 1], [5, 2], [8, 4]]]
[7, 4, 1, [[1, 6], [4, 2], [9, 5]]]
[9, 2, 1, [[2, 4], [7, 3], [10, 6]]]
[9, 3, 1, [[3, 5], [6, 3], [8, 6], [10, 7]]]
[9, 4, 1, [[4, 4], [7, 6], [9, 3], [11, 5]]]
[12, 5, 1, [[5, 5], [8, 3], [11, 9]]]
[15, 6, 1, [[6, 6], [7, 7], [11, 8]]]
[14, 8, 1, [[8, 5], [9, 9], [10, 8]]]


Distance of node  b  :  3
Path                 :  b <-  a

Distance of node  c  :  5
Path                 :  c <-  a

Distance of node  d  :  4
Path                 :  d <-  a

Distance of node  e  :  5
Path                 :  e <-  d <-  a

Distance of node  f  :  7
Path                 :  f <-  e <-  d <-  a

Distance of node  g  :  9
Path                 :  g <-  c <-  a

Distance of node  h  :  9
Path                 :  h <-  d <-  a

Distance of node  i  :  9
Path                 :  i <-  e <-  d <-  a

Distance of node  j  :  12
Path                 :  j <-  f <-  e <-  d <-  a

Distance of node  k  :  15
Path                 :  k <-  g <-  c <-  a

Distance of node  l  :  14
Path                 :  l <-  i <-  e <-  d <-  a
'''

