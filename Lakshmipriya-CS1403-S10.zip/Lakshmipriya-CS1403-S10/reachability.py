# -*- coding: utf-8 -*-
"""
@author: Lakshmi Priya
"""

def warshall(T):
    n=len(T)
    for k in range(0, n): 
        for i in range(0, n): 
            for j in range(0, n): 
                T[i][j] = T[i][j] or (T[i][k] and T[k][j])

    print("\n\nReachability Matrix / Transitive Closure")
    for rows in T:
        print(rows)




T = [[0, 1, 0, 0],
     [0, 0, 0, 1],
     [0, 0, 0, 0],
     [1, 0, 1, 0]]

print("Adjacency Matrix")
for rows in T:
    print(rows)
    
warshall(T)
