# -*- coding: utf-8 -*-
"""
@author: Lakshmi Priya
"""
import math

def printPath(P, i, j, vertex):
    k=P[i][j]
    if(k==-1):
        print("->", vertex[j], end='')
    else:
        printPath(P, i, k, vertex)
        printPath(P, k, j, vertex)

def floyd_warshall(Adj, vertex):
    n=len(Adj)
    D=[[Adj[i][j] for j in range(0, n)] for i in range(0, n)]
    P=[[-1 for j in range(0, n)] for i in range(0, n)]
    
    for k in range(n): 
        for i in range(n): 
            for j in range(n): 
                if (D[i][j] > D[i][k] + D[k][j]): 
                    D[i][j] = D[i][k] + D[k][j] 
                    P[i][j] = k

    print("\n\nDistance Matrix")
    for rows in D:
        print(rows)

    print("\n\nPath Matrix")
    for rows in P:
        print(rows)
    
    for i in range(n):
        print("\n\nStartnode: ", vertex[i])
        for j in range(n):
            if(i!=j):
                print("\n\nEndnode : ", vertex[j])
                print("Distance: ", D[i][j])
                print("Path    : ", end='')
                if(D[i][j]!=INF):
                    print("", vertex[i], end='')
                    printPath(P, i, j, vertex)
        print("\n***************")
            
            
        



INF=math.inf

vertex=["a", "b", "c", "d", "e", "f"]

T = [[0, 10, 15, INF, INF, INF],
     [INF, 0, INF, 12, INF, 15],
     [INF, INF, 0, INF, 10, INF],
     [INF, INF, INF, 0, 2, 1],
     [INF, INF, INF, INF, 0, INF],
     [INF, INF, INF, INF, 5, 0]
     ]

print("Adjacency Matrix")
for rows in T:
    print(rows)
    
floyd_warshall(T, vertex)
