# -*- coding: utf-8 -*-
"""
@author: Lakshmi Priya
"""

import math

class Node:
	def __init__(self, vertex, dist):
		self.vertex = vertex
		self.dist = dist


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node(-1, -math.inf))   #sentinel for heap set
	return heap

heapindex=[]

def decreaseKey(heap, node):  
	i=heapindex[node.vertex]
    
	heap[i].vertex=node.vertex
	heap[i].dist=node.dist
    
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].dist < heap[parent].dist):
			heapindex[i]=parent
			heapindex[parent]=i
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2
    

def increaseKey(heap, node):
	i=heapindex[node.vertex]

	heap[i].vertex=node.vertex
	heap[i].dist=node.dist

	while(2*i <= len(heap)-2):
		child=2*i
		if(heap[child].dist > heap[child+1].dist):
			child += 1
		if(heap[i].dist > heap[child].dist):
			heapindex[i]=child
			heapindex[child]=i
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child

        
def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	heapindex[node.vertex]=len(heap)-1
	decreaseKey(heap, node)
    
def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
		heapindex[len(heap)-1]=-1
		return heap.pop()
	heap[1]=heap.pop()
	heapindex[heap[1].vertex]=1
	increaseKey(heap, heap[1])
	return minval


def dijkstra(n, startnode, graph, vertex):
    #[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]
	heap = buildheap();
    
	INFINITY = math.inf
            
	insertheap(heap, Node(startnode, 0))
        
	graph[startnode][0]=0             #set distance of startnode
	graph[startnode][2]=1             #set startnode as known 
	
	nextnode=-1
    
	while(len(heap)>1):
		mindistance=INFINITY   
		while(len(heap)>1):                 #find unvisited node with min distance
			minNode = deletemin(heap)
			nextnode = minNode.vertex
			mindistance = minNode.dist
            
			if(graph[nextnode][2]==0):
				break
        
		graph[nextnode][2]=1               #set nextnode as known
        
		for adj in graph[nextnode][3]:     #check and update distance of adjacent nodes of nextnode
			index=adj[0]
			cost=adj[1]
			if(mindistance+cost < graph[index][0]):
				graph[index][0]=mindistance+cost
				graph[index][1]=nextnode
			insertheap(heap, Node(index, graph[index][0])) 
	
	'''
	print("Graph data: ")                
	print("[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]")

	for i in graph:
		print(i)
	'''
	
	for i in range(n):	            #print shortest path from startnode to all other nodes
		if(i!=startnode):
			print("\n\nDistance of node ",vertex[i], " : ", graph[i][0])
			print("Path                 : ", end=' ')		
			j=i
			if(graph[i][0]!=INFINITY):
				print(vertex[i], end="")
				while(True):			
					j=graph[j][1]
					print(" <- ", vertex[j], end="")
					if(j==startnode):
						break
	
	


heap=buildheap()

INF=math.inf

vertex = ["a", "b", "c", "d", "e", "f"]
n=len(vertex)

#[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]

for i in range(n):
    heapindex.append(-1)

for i in range(n):
    
	graph=[ [INF, -1, 0, [ [1, 10], [2, 15] ]   ] ,   #a
            [INF, -1, 0, [ [3, 12], [5, 15] ]   ] ,   #b         
            [INF, -1, 0, [ [4, 10]          ]   ] ,   #c         
            [INF, -1, 0, [ [4, 2], [5, 1]   ]   ] ,   #d         
            [INF, -1, 0, [                  ]   ] ,   #e
            [INF, -1, 0, [ [4, 5]           ]   ]     #f
         ]
	print("\n\nStartnode: ", vertex[i])
	dijkstra(n, i, graph, vertex)
	print("\n******************")

