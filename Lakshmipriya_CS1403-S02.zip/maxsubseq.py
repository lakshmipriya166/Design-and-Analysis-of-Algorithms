import random
import time
import math
import xlwt
from xlwt import Workbook


def maxSubSeqCubic(lst):
	n=len(lst)
	maxsum=0
	for i in range(0,n):
		for j in range(i,n):
			summ=0
			for k in range(i,j+1):
				summ+=lst[k]
			if(summ>maxsum):
				maxsum=summ
	return maxsum


def maxSubSeqQuadratic(lst):
	n=len(lst)
	maxsum=0
	for i in range(0,n):
		summ=0
		for j in range(i,n):
			summ+=lst[j]
			if(summ>maxsum):
				maxsum=summ
	return maxsum


def maxSubSeqLinear(lst):
	n=len(lst)
	maxsum=0
	summ=0
	for i in range(0,n):
		summ+=lst[i]
		if(summ>maxsum):
			maxsum=summ
		elif(summ<0):
			summ=0
	return maxsum


def maxMiddleSeqSum(lst, l, m, r): 
    summ=0
    lsum=0     
    for i in range(m, l-1, -1): 
        summ=summ+lst[i] 
          
        if (summ > lsum): 
            lsum=summ 
     
    summ=0
    rsum=0
    for i in range(m + 1, r + 1): 
        summ=summ+lst[i] 
          
        if (summ > rsum) : 
            rsum=summ 

    return lsum+rsum; 
  
  
def maxSubSeqDC(lst, l, r): 
    if (l==r): 
        return lst[l] 
    m = (l+r)//2
    return max(maxSubSeqDC(lst, l, m), maxSubSeqDC(lst, m+1, r), maxMiddleSeqSum(lst, l, m, r)) 


def comptable(func, sheet):     #Simultaneously writes into excel sheet
	print("n  \tT(n)", end='\t')
	print("%11s\t%11s\t%11s\t%11s\t%11s" %("T(n)/log(n)", "T(n)/n", "T(n)/n^2", "T(n)/n^3", "2T(n)/2^n"))
	i=1
	for n in range(10,300,30):
		j=0	
		lst = random.sample(range(-1000, 1000), n)
		totaltime=0
		for m in range(0, 100):
			start=time.time()
			func(lst)
			end=time.time()
			totaltime+=(end-start)
		avgtime=totaltime/100
		print("%3d  %.5f" %(n, avgtime), end='\t')

		sheet.write(i, j, n)
		j=j+1
		sheet.write(i, j, avgtime)
		j=j+1

		num=math.log(n)
		ratio=avgtime/num
		print("%.5e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1
		
		num=n
		ratio=avgtime/num
		print("%.5e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=n**2
		ratio=avgtime/num
		print("%.5e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=n**3
		ratio=avgtime/num
		print("%.5e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=2**n
		ratio=avgtime/num
		print("%.5e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		print()
		i=i+1

def addSheetTitle(sheet):
	sheet.write(0, 0, "n")  
	sheet.write(0, 1, "T(n)")
	sheet.write(0, 2, "log(n)")
	sheet.write(0, 3, "T(n)/log(n)")
	sheet.write(0, 4, "n")
	sheet.write(0, 5, "T(n)/n")
	sheet.write(0, 6, "n^2")
	sheet.write(0, 7, "T(n)/n^2")
	sheet.write(0, 8, "n^3")
	sheet.write(0, 9, "T(n)/n^3")
	sheet.write(0, 10, "2^n")
	sheet.write(0, 11, "2T(n)/2^n")

wb=Workbook()
sheet1=wb.add_sheet('Brute force')
sheet2=wb.add_sheet('DP')
sheet3=wb.add_sheet('Greedy')

addSheetTitle(sheet1)
addSheetTitle(sheet2)
addSheetTitle(sheet3)

print("Brute force approach: ")
comptable(maxSubSeqCubic, sheet1)
print()

print("Dynamic programming approach: ")
comptable(maxSubSeqQuadratic, sheet2)
print()

print("Greedy approach: ")
comptable(maxSubSeqLinear, sheet3)
print()

wb.save('maxsubseq.xls')

print("Divide & Conquer approach: ")

lst = random.sample(range(-1000, 1000), 5) 
print(lst)
print("Max Subsequence Sum = ", maxSubSeqDC(lst, 0, len(lst)-1)) 
print()

lst = random.sample(range(-1000, 1000), 10) 
print(lst)
print("Max Subsequence Sum = ", maxSubSeqDC(lst, 0, len(lst)-1)) 
print()

lst = random.sample(range(-1000, 1000), 15) 
print(lst)
print("Max Subsequence Sum = ", maxSubSeqDC(lst, 0, len(lst)-1)) 










