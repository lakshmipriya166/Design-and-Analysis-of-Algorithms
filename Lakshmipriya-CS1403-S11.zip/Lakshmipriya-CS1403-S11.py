# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 15:24:17 2020

@author: Lakshmi Priya
"""
from itertools import permutations

freq=dict()
s1="BB"
s2="A"
res="ACC"


for i in s1:
	if i in freq.keys():
		freq[i]+=1
	else:
		freq[i]=1

for i in s2:
	if i in freq.keys():
		freq[i]+=1
	else:
		freq[i]=1

for i in res:
	if i in freq.keys():
		freq[i]+=1
	else:
		freq[i]=1


#print(freq)
n=len(freq)


def check(item):
	i=0
	for key in freq:
		freq[key]=item[i]
		i+=1
	#print(freq)
	
	tot1=0
	for j in range(len(s1)):
		tot1+=freq[s1[j]]*(10**(len(s1)-1-j))
	for j in range(len(s2)):
		tot1+=freq[s2[j]]*(10**(len(s2)-1-j))

	tot2=0
	for j in range(len(res)):
		tot2+=freq[res[j]]*(10**(len(res)-1-j))
	#print(tot1,tot2)
	if(tot1==tot2 and freq[s1[0]]!=0 and freq[s2[0]]!=0 and freq[res[0]]!=0 ):
		print("Found: "+str(freq))
		return True


def bfs(queue):
    while(len(queue)!=0):
        lst=queue.pop(0)
        if check(lst)==True:
            return lst
        for i in range(len(lst)-1):
            for j in range(i+1, len(lst)):
                lst[i], lst[j]=lst[j], lst[i]
                if(tuple(lst) not in visited):
                    queue.append(lst[:])
                    visited[tuple(lst)]=1
    


def dfs(stack):
    while(len(stack)!=0):
        lst=stack.pop()
        if check(lst)==True:
            return lst
        for i in range(len(lst)-1):
            for j in range(i+1, len(lst)):
                lst[i], lst[j]=lst[j], lst[i]
                if(tuple(lst) not in visited):
                    stack.append(lst[:])
                    visited[tuple(lst)]=1


def backtrack(lettersToAssign):
	if (len(lettersToAssign)==0):                # no more choices to make 
		return check(list(freq.values()))        # checks arithmetic to see if works 
    
	for i in range(10):                          # try all digits 
		temp=freq[lettersToAssign[0]]
		freq[lettersToAssign[0]]=i
		 
		if (backtrack(lettersToAssign[1:])):
			return True 
		freq[lettersToAssign[0]]=temp
		 	
	return False               # nothing worked, need to backtrack 


def exhaustive():
    n=len(freq)
    
    l = list(permutations([0,1,2,3,4,5,6,7,8,9], n) )
    
    for item in l:
        if(check(item)):
            return
      
        
print("\n\nSolving using BFS state space approach...")
queue=[]
queue.append([0,1,2,3,4,5,6,7,8,9])
visited=dict()
visited[tuple([0,1,2,3,4,5,6,7,8,9])]=1
bfs(queue)

print("\n\nSolving using DFS state space approach...")
stack=[]
stack.append([0,1,2,3,4,5,6,7,8,9])
visited=dict()
visited[tuple([0,1,2,3,4,5,6,7,8,9])]=1
dfs(stack)

print("\n\nSolving using BACKTRACKING state space approach...")
backtrack(list(freq.keys()))

print("\n\nSolving using exhaustive search against all permutations...")
exhaustive()





'''	
ANSWER:
Found: {'S': 3, 'H': 6, 'A': 5, 'N': 8, 'T': 7, 'M': 9, 'E': 2, 'G': 4, 'D': 1, 'I': 0}



Solving using BFS state space approach...
Found: {'B': 9, 'A': 1, 'C': 0}


Solving using DFS state space approach...
Found: {'B': 9, 'A': 1, 'C': 0}


Solving using BACKTRACKING state space approach...
Found: {'B': 9, 'A': 1, 'C': 0}


Solving using exhaustive search against all permutations...
Found: {'B': 9, 'A': 1, 'C': 0}
'''



