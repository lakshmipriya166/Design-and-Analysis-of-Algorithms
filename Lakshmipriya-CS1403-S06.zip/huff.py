# -*- coding: utf-8 -*-
"""
@author: Lakshmi Priya
"""

class Node:
	def __init__(self, symbol, prob, left, right):
		self.left = left
		self.right = right
		self.symbol = symbol
		self.prob = prob


def buildheap():                    #heap of Node(s)
	heap=[]
	heap.append(Node("", 0, None, None))       #sentinel for heap set
	return heap

def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].prob < heap[parent].prob):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                #Node with min probability deleted
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-2):
		child=2*i
		if(heap[child].prob > heap[child+1].prob):
			child += 1
		if(heap[i].prob > heap[child].prob):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=2*i
	return minval

def huffman(heap):                  

	while(len(heap) > 2):          #Iterates until heap contains sentinel + single node
		left = deletemin(heap)
		newprob = left.prob
		if(len(heap) > 1):
			right = deletemin(heap)
			newprob += right.prob
		else:
			right = None

		n = Node("", newprob, left, right)
		insertheap(heap, n)

	return deletemin(heap)

def printCodes(root, code):         #prints the codes by travering the tree
    if (root.symbol == "" and root.left != None):
        printCodes(root.left, code+"0")
   
    if (root.symbol == "" and root.right != None):
        printCodes(root.right, code+"1") 
  
    if (root.symbol != ""):
        print("SYMBOL : ",root.symbol,"\tCODE : ",code)
    

    

heap=buildheap()

insertheap(heap, Node("a", 0.24, None, None))
insertheap(heap, Node("b", 0.16, None, None))
insertheap(heap, Node("c", 0.11, None, None))
insertheap(heap, Node("d", 0.09, None, None))
insertheap(heap, Node("e", 0.40, None, None))

for i in range(1, len(heap)):
	print("SYMBOL : ",heap[i].symbol, "PROBABILITY : ", heap[i].prob)
    
print("\n\n****HUFFMAN CODING****")


nodespace = huffman(heap)

printCodes(nodespace, "")

