# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 07:50:01 2020

@author: Lakshmi Priya
"""


def dissimilarityBruteForce(lst):
    dcount=0                            # Let n=len(lst)
    for i in range(0, len(lst)-1):      # complexity of i loop: O(n)
        for j in range(i+1, len(lst)):      # complexity of j loop: O(n) 
            if(lst[i]>lst[j]):
                dcount+=1               #By rule of products,
    return dcount                       #Time complexity = O(n)*O(n) = O(n^2)


"""
Let T(n)=aT(n/b)+f(n), where a ≥ 1 and b > 1 
Merge sort is of the above form.

When a =b, if f(n) is linear time, then T(n) is Θ(nlogn) 

"""

def mergeInv(lst1, lst2):
	count=0
	i = j = 0
	arr=[]

	while(i<len(lst1) and j<len(lst2)): 
		if (lst1[i] <= lst2[j]): 
			arr.append(lst1[i]) 
			i+=1
		else: 
			arr.append(lst2[j]) 
			count+=len(lst1)-i
			j+=1
	arr.extend(lst1[i:])
	arr.extend(lst2[j:])
	return arr,count


def mergesortInv(arr, count):
	count=0
	if(len(arr)<2):
		return arr, 0
	else:
		mid = len(arr)//2 
		left, lcount = mergesortInv(arr[:mid], count)  
		right, rcount = mergesortInv(arr[mid:], count) 
	merge, midcount=mergeInv(left, right)
	return merge, lcount+rcount+midcount
        
    

print("Using Brute Force approach: ")

print("[1,2,3,4,5] -> "+str(dissimilarityBruteForce([1,2,3,4,5])))
print("[2,4,1,3,5] -> "+str(dissimilarityBruteForce([2,4,1,3,5])))
print("[3,1,2,5,4] -> "+str(dissimilarityBruteForce([3,1,2,5,4])))
print("[4,5,2,1,3] -> "+str(dissimilarityBruteForce([4,5,2,1,3])))
print("[5,4,3,2,1] -> "+str(dissimilarityBruteForce([5,4,3,2,1])))


print("Using modified mergesort approach: ")

print(mergesortInv([1,2,3,4,5], 0))
print(mergesortInv([2,4,1,3,5], 0)) 
print(mergesortInv([3,1,2,5,4], 0))
print(mergesortInv([4,5,2,1,3], 0))
print(mergesortInv([5,4,3,2,1], 0))


'''
print(arr)
n=int(input("Enter number of lists: "))
for i in range(n):
    print("\nEnter elements in list: ", end=' ')
    lst=[int(x) for x in input().split(",")]
    print(lst)
    print("\n"+str(lst)+" -> ", end='')
    print(dissimilarityBruteForce(lst))
'''   
    

                
        