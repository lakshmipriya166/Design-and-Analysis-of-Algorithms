# -*- coding: utf-8 -*-
"""
Created on Sat Mar 14 20:38:55 2020

@author: Lakshmi Priya
"""

import math
import copy


class Node:
	def __init__(self, state, cost, space_row, space_col):
		self.state = state
		self.cost = cost
		self.space_row=space_row
		self.space_col=space_col

	def __repr__(self):
		return str((self.state, self.cost))


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node([], -math.inf, 0, 0))   #sentinel for heap set
	return heap

        
def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].cost < heap[parent].cost):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-1):
		child=2*i
		if(child+1 < len(heap) and heap[child].cost > heap[child+1].cost):
			child += 1
		if(heap[i].cost > heap[child].cost):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child
	return minval


goalstate=[ [0,0], [0,1], [0,2], 
			[1,0], [1,1], [1,2], 
			[2,0], [2,1], [2,2]
		  ]

def heuristics(puzzle):
	h=0
	for i in range(len(puzzle)):
		for j in range(len(puzzle[0])):
			if(puzzle[i][j]!=-1):
				h+=abs(i-goalstate[puzzle[i][j]][0])+abs(j-goalstate[puzzle[i][j]][1])
	return h


def npuzzle(node):
	puzzle=node.state
	x=node.space_row
	y=node.space_col

	n=len(puzzle)
	if(heuristics(puzzle)==0):
		return
	if(x>0):   #slide space UP
		p=copy.deepcopy(puzzle)
		p[x][y], p[x-1][y] = p[x-1][y], p[x][y]
		insertheap(heap, Node(p, heuristics(p), x-1, y))
	if(x<n-1):   #slide space DOWN
		p=copy.deepcopy(puzzle)
		p[x][y], p[x+1][y] = p[x+1][y], p[x][y]
		insertheap(heap, Node(p, heuristics(p), x+1, y))
	if(y>0):   #slide space LEFT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y-1] = p[x][y-1], p[x][y]
		insertheap(heap, Node(p, heuristics(p), x, y-1))
	if(y<n-1):   #slide space RIGHT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y+1] = p[x][y+1], p[x][y]
		insertheap(heap, Node(p, heuristics(p), x, y+1))
    
	nextnode=deletemin(heap)
	print(nextnode.state)
	npuzzle(nextnode)
	
    
def heuristics2(puzzle, cost):
	h=cost
	for i in range(len(puzzle)):
		for j in range(len(puzzle[0])):
			if(puzzle[i][j]!=-1):
				h+=abs(i-goalstate[puzzle[i][j]][0])+abs(j-goalstate[puzzle[i][j]][1])
	return h



def npuzzle2(node):
	puzzle=node.state
	cost=node.cost
	x=node.space_row
	y=node.space_col
	n=len(puzzle)
	if(heuristics(puzzle)==0):
		return
	if(x>0):   #slide space UP
		p=copy.deepcopy(puzzle)
		p[x][y], p[x-1][y] = p[x-1][y], p[x][y]
		insertheap(heap, Node(p, heuristics2(p, cost), x-1, y))
	if(x<n-1):   #slide space DOWN
		p=copy.deepcopy(puzzle)
		p[x][y], p[x+1][y] = p[x+1][y], p[x][y]
		insertheap(heap, Node(p, heuristics2(p, cost), x+1, y))
	if(y>0):   #slide space LEFT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y-1] = p[x][y-1], p[x][y]
		insertheap(heap, Node(p, heuristics2(p, cost), x, y-1))
	if(y<n-1):   #slide space RIGHT
		p=copy.deepcopy(puzzle)
		p[x][y], p[x][y+1] = p[x][y+1], p[x][y]
		insertheap(heap, Node(p, heuristics2(p, cost), x, y+1))
	nextnode=deletemin(heap)
	print(nextnode.state)
	npuzzle2(nextnode)

'''
puzzle=[[2, 1, 6],
		[4, 7, -1],
		[0, 3, 5]
	   ]
spaceindex=[1,2]

'''
puzzle=[[0, 4, 1],
		[-1, 7, 2],
		[3, 6, 5]
	   ]
spaceindex=[1,0]


heap=buildheap()
print("\n\nn puzzle using a heuristics function h(s):")
print(puzzle)
npuzzle(Node(puzzle, heuristics(puzzle), spaceindex[0], spaceindex[1]))


heap=buildheap()
print("\n\nn puzzle using  an evaluation function f(s) = g(s) + h(s):")
print(puzzle)
npuzzle2(Node(puzzle, heuristics2(puzzle, 0), spaceindex[0], spaceindex[1]))

'''
SOLUTION


n puzzle using a heuristics function h(s):
[[0, 4, 1], [-1, 7, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 4, 1], [3, 7, 2], [6, -1, 5]]
[[0, 4, 1], [3, -1, 2], [6, 7, 5]]
[[0, -1, 1], [3, 4, 2], [6, 7, 5]]
[[0, 1, -1], [3, 4, 2], [6, 7, 5]]
[[0, 1, 2], [3, 4, -1], [6, 7, 5]]
[[0, 1, 2], [3, 4, 5], [6, 7, -1]]


n puzzle using  an evaluation function f(s) = g(s) + h(s):
[[0, 4, 1], [-1, 7, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 4, 1], [7, -1, 2], [3, 6, 5]]
[[-1, 4, 1], [0, 7, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [6, -1, 5]]
[[0, 4, 1], [-1, 7, 2], [3, 6, 5]]
[[0, -1, 1], [7, 4, 2], [3, 6, 5]]
[[0, 4, 1], [3, -1, 2], [6, 7, 5]]
[[0, 4, 1], [-1, 7, 2], [3, 6, 5]]
[[0, 4, 1], [-1, 7, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [6, 5, -1]]
[[0, 4, 1], [7, 2, -1], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 4, 1], [7, 6, 2], [3, -1, 5]]
[[4, -1, 1], [0, 7, 2], [3, 6, 5]]
[[0, -1, 1], [3, 4, 2], [6, 7, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 4, 1], [-1, 3, 2], [6, 7, 5]]
[[0, 4, 1], [3, 2, -1], [6, 7, 5]]
[[0, 4, 1], [3, 7, 2], [6, -1, 5]]
[[0, 1, -1], [3, 4, 2], [6, 7, 5]]
[[0, 4, 1], [7, -1, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 1, 2], [3, 4, -1], [6, 7, 5]]
[[-1, 4, 1], [0, 7, 2], [3, 6, 5]]
[[0, 4, 1], [3, 7, 2], [-1, 6, 5]]
[[0, 1, 2], [3, 4, 5], [6, 7, -1]]
'''