# -*- coding: utf-8 -*-
"""

@author: Lakshmi Priya
"""

def tobinary(n):
    if(n==0):
        return 0
    elif(n==1):
        return 1
    else:
        return tobinary(n//2)*10+n%2

def mult(m1, m2):
    result=[]
    for i in range(0, len(m1)):
        result.append([0]*len(m2[0]))
        
    for i in range(0, len(m1)):
        for j in range(0, len(m2[0])):
            for k in range(0, len(m2)):
                result[i][j]+=m1[i][k]*m2[k][j]
    #print(m1,m2,result)
    return result
			

def fastexp(m, n):
	b=bin(n).replace("0b", "")

	term=m
	result=[[1,0],[0,1]]
    
	if(b[-1]=='1'):
		result=m
        
	for i in range(2, len(b)+1):
		term=mult(term, term)	
		if(b[-i]=='1'):
			result=mult(result, term)

	return result
			
			 
def fib(n):
	m=[[1,1],[1,0]]
	result=fastexp(m, n-1)
	ans=mult(result, [[1],[0]])
	return ans[0][0]	



n=2
r=2
c=2

mat=[[1,1],[1,0]]

for i in range(0,r):
	for j in range(0,c):
		print(mat[i][j] , end="   ")
	print("\n")

result=fastexp(mat, n)

print("Resultant Matrix of fastexp(mat, n): \n")
for i in range(0, len(result)):
	for j in range(0, len(result[0])):
		print(result[i][j] , end="   ")
	print("\n")

print("fib(0) = ",fib(0))
print("fib(2) = ",fib(2))
print("fib(4) = ",fib(4))
print("fib(5) = ",fib(5))
print("fib(6) = ",fib(6))