# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 19:33:46 2019

@author: Lakshmi Priya
"""

def linear_locate(item, list):
    if(len(list)==0 or list[0]>=item):
        return 0
    else:
        return 1+linear_locate(item, list[1:])

    
def tail_linear_locate(item, list, index):
    if(len(list)==0):
        return 0
    elif(list[index] >= item):
        return index
    else:
        return tail_linear_locate(item, list, index+1)


def itr_linear_locate(item, list):
    i=0
    for i in range(len(list)):
        if(list[i]>=item):
            return i
    return i

     
def linear_search(item, list):
    index=linear_locate(item, list)
    if(index==len(list)):
        return -1
    elif(item==list[index]):
        return index
    return -1


def ordered_insert(item, list):
    if(len(list)==0 or list[0]>=item):
        return [item]+list
    else:
        return [list[0]]+ordered_insert(item, list[1:])

    
def itr_ordered_insert(item, list):
    index=itr_linear_locate(item, list)
    list.insert(index, item)
    return list


def insertion_sort(list):
    if(len(list)==0):
        return []
    else:
        return ordered_insert(list[0], insertion_sort(list[1:]))
    

def oinsert(list, j):
    if(j<0):
        return []
    while(j>0 and list[j-1]>list[j]):
        list[j], list[j-1]=list[j-1], list[j]
        j-=1   
    return list


def oinsert_rev(list, j):
    if(j==len(list)):
        return list
    while(j<len(list)-1 and list[j+1]<list[j]):
        list[j], list[j+1]=list[j+1], list[j]
        j+=1   
    return list
   

def oinsert2(list, j):
    if(j==-1):
        return []
    target=list[j]
    while(j>0 and list[j-1] > target):
        list[j]=list[j-1]
        j=j-1
    list[j]=target        
    return list
    

def recurr_insertion_sort(list, n):
    if (n<1):
        return
    recurr_insertion_sort(list, n-1)
    
    return oinsert(list, n)


def itr_insertion_sort(list):
    for i in range(1, len(list)):
        oinsert(list, i)
        
    return list
   
 
def main():
    print("linear_locate(15, [5, 10, 20, 35, 50]) = ", linear_locate(15, [5, 10, 20, 35, 50]))
    print("linear_locate(35, [5, 10, 20, 35, 50]) = ", linear_locate(35, [5, 10, 20, 35, 50]))
    print("linear_locate(2, [5, 10, 20, 35, 50])  = ", linear_locate(2, [5, 10, 20, 35, 50]))
    print("linear_locate(25, [])                  = ", linear_locate(25, []))
    print("\n")
    print("tail_linear_locate(15, [5, 10, 20, 35, 50], 0) = ", tail_linear_locate(15, [5, 10, 20, 35, 50], 0))
    print("tail_linear_locate(35, [5, 10, 20, 35, 50], 0) = ", tail_linear_locate(35, [5, 10, 20, 35, 50], 0))
    print("tail_linear_locate(2, [5, 10, 20, 35, 50], 0)  = ", tail_linear_locate(2, [5, 10, 20, 35, 50], 0))
    print("tail_linear_locate(25, [], 0)                  = ", tail_linear_locate(25, [], 0))
    print("\n")
    print("itr_linear_locate(15, [5, 10, 20, 35, 50]) = ", itr_linear_locate(15, [5, 10, 20, 35, 50]))
    print("itr_linear_locate(35, [5, 10, 20, 35, 50]) = ", itr_linear_locate(35, [5, 10, 20, 35, 50]))
    print("itr_linear_locate(2, [5, 10, 20, 35, 50])  = ", itr_linear_locate(2, [5, 10, 20, 35, 50]))
    print("itr_linear_locate(25, [])                  = ", itr_linear_locate(25, []))
    print("\n")
    print("linear_search(15, [5, 10, 20, 35, 50]) = ", linear_search(15, [5, 10, 20, 35, 50]))
    print("linear_search(35, [5, 10, 20, 35, 50]) = ", linear_search(35, [5, 10, 20, 35, 50]))
    print("linear_search(2, [5, 10, 20, 35, 50])  = ", linear_search(2, [5, 10, 20, 35, 50]))
    print("linear_search(25, [])                  = ", linear_search(25, []))
    print("\n")
    print("ordered_insert(15, [5, 10, 20, 35, 50]) = ", ordered_insert(15, [5, 10, 20, 35, 50]))
    print("ordered_insert(35, [5, 10, 20, 35, 50]) = ", ordered_insert(35, [5, 10, 20, 35, 50]))
    print("ordered_insert(2, [5, 10, 20, 35, 50])  = ", ordered_insert(2, [5, 10, 20, 35, 50]))
    print("ordered_insert(25, [])                  = ", ordered_insert(25, []))
    print("\n")
    print("itr_ordered_insert(15, [5, 10, 20, 35, 50]) = ", itr_ordered_insert(15, [5, 10, 20, 35, 50]))
    print("itr_ordered_insert(35, [5, 10, 20, 35, 50]) = ", itr_ordered_insert(35, [5, 10, 20, 35, 50]))
    print("itr_ordered_insert(2, [5, 10, 20, 35, 50])  = ", itr_ordered_insert(2, [5, 10, 20, 35, 50]))
    print("itr_ordered_insert(25, [])                  = ", itr_ordered_insert(25, []))
    print("\n")
    print("insertion_sort([50, 20, 10, 35, 10]) = ", insertion_sort([50, 20, 10, 35, 10]))
    print("insertion_sort([5, 4, 3, 2, 1])      = ", insertion_sort([5, 4, 3, 2, 1]))
    print("insertion_sort([50, 10, 20, 35, 50]) = ", insertion_sort([50, 10, 20, 35, 50]))
    print("insertion_sort([])                   = ", insertion_sort([]))
    print("\n")
    print("itr_insertion_sort([50, 20, 10, 35, 10]) = ", itr_insertion_sort([50, 20, 10, 35, 10]))
    print("itr_insertion_sort([5, 4, 3, 2, 1])      = ", itr_insertion_sort([5, 4, 3, 2, 1]))
    print("itr_insertion_sort([50, 10, 20, 35, 50]) = ", itr_insertion_sort([50, 10, 20, 35, 50]))
    print("itr_insertion_sort([])                   = ", itr_insertion_sort([]))   
    print("\n")
    print("oinsert([],-1)     = ", oinsert([],-1))
    print("oinsert([1,0],1)   = ", oinsert([1,0],1))
    print("oinsert([1],0)     = ", oinsert([1],0))
    print("oinsert([1,5,2],2) = ", oinsert([1,5,2],2))
    print("\n")
    print("oinsert2([],-1)     = ", oinsert2([],-1))
    print("oinsert2([1,0],1)   = ", oinsert2([1,0],1))
    print("oinsert2([1],0)     = ", oinsert2([1],0))
    print("oinsert2([1,5,2],2) = ", oinsert2([1,5,2],2))
    print("\n")
    print("oinsert_rev([],-1)       = ", oinsert_rev([],-1))
    print("oinsert_rev([1,0,4,3],2) = ", oinsert_rev([1,0,4,3],2))
    print("oinsert_rev([1],0)       = ", oinsert_rev([1],0))
    print("oinsert_rev([10,3,4],0)  = ", oinsert_rev([10,3,4],0))    
    print("\n")
    print("recurr_insertion_sort([50, 20, 10, 35, 10], 4) = ", recurr_insertion_sort([50, 20, 10, 35, 10], 4))
    print("recurr_insertion_sort([5, 4, 3, 2, 1], 4)      = ", recurr_insertion_sort([5, 4, 3, 2, 1], 4))
    print("recurr_insertion_sort([50, 10, 20, 35, 50], 4) = ", recurr_insertion_sort([50, 10, 20, 35, 50], 4))
    print("recurr_insertion_sort([], -1)                   = ", recurr_insertion_sort([], -1))





    
main()