# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 18:36:32 2019

@author: Lakshmi Priya
"""

def print_array(a, low, high):
    print(a[low:high])
  

def read_array():
    n=int(input("Enter number of integers in array: "))
    a=[]
    
    print("Enter items: ")
    for i in range(n):
        a.append(int(input()))
    return a, n

def minimum(a, low, high):
    return a.index(min(a[low : high]))


def selsort(a):
    n=len(a)
    for i in range(n-1):
        minindex=minimum(a, i, n)
        a[i], a[minindex] = a[minindex], a[i]


        
def main():       
    a=[5,4,3,2,1]
    print("Testing print_array...")
    print("Array = ", a)
    print_array(a, 1, 3)
    
    a, n= read_array()
    
    print("\nArray = ", a, "\nCount = ",n)
    
    print("minimum(", a, ", 1, 4) index = ", minimum(a, 1, 4))
    print("minimum(", a, ", 0, 2) index = ", minimum(a, 0, 2))
    
    
    n=int(input("Enter number of arrays to be sorted: "))
    
    for i in range(n):
        a, size=read_array()
        print("Array: ")
        print_array(a, 0, size)
        selsort(a)
        print("Sorted array: ", a)
    
    
    
main()