# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 20:55:55 2019

@author: Lakshmi Priya
"""

def ordered_merge(u, v):
    if(u==[]):
        return v
    elif(v==[]):
        return u
    elif(u[0]<v[0]):
        return [u[0]] + ordered_merge(u[1:], v)
    else:
        return [v[0]] + ordered_merge(u, v[1:])


def itr_ordered_merge(u, v):
    uindex=0
    vindex=0
    lst=[]
    while(uindex!=len(u) and vindex!=len(v)):
        if(u[uindex] < v[vindex]):
            lst.append(u[uindex])
            uindex=uindex+1
        else:
            lst.append(v[vindex])
            vindex=vindex+1
    if(uindex!=len(u)):
        lst.extend(u[uindex:])
    elif(vindex!=len(v)):
        lst.extend(v[vindex:])
    return lst
    
            
    
def main():
    print(ordered_merge([2,5,9], [1,6,8]))
    print(ordered_merge ([15, 40, 45], [5, 10, 20, 35, 50]))
    print(ordered_merge ([30, 60], [20, 35, 50]))
    print(ordered_merge ([], [20, 35, 50]))
    print("\n")
    print(itr_ordered_merge([2,5,9], [1,6,8]))
    print(itr_ordered_merge ([15, 40, 45], [5, 10, 20, 35, 50]))
    print(itr_ordered_merge ([30, 60], [20, 35, 50]))
    print(itr_ordered_merge ([], [20, 35, 50]))
    
    

main()