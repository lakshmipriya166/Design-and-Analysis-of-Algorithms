# -*- coding: utf-8 -*-
"""
Created on Wed Dec 18 22:50:00 2019

@author: Lakshmi Priya
"""

def heapsort(list, j):
    if(j==len(list)):
        return list
    while(j<len(list)-1 and list[j*2]<list[j]):
        list[j], list[j*2]=list[j*2], list[j]
        j*=2   
    return list

def main():
    a=[0,100,2,0,4,0,0,0,6]
    print(heapsort(a, 1))
    
main()