import random
import time
import math
from xlwt import Workbook

def knapsack(i, j, weights, values, book):
	if i<0 or j<0:
		return 0
	if book[i][j] <= 0:
		if j < weights [i]:
			value = knapsack(i-1, j, weights, values, book)
		else:
			value =max(knapsack(i-1, j, weights, values, book), 
                       values[i] + knapsack(i-1, j-weights[i], weights, values, book))
		book[i][j] = value 
	return book[i][j]


def printSelected(res, book):
    print("\nItems Selected")
    w = W 
    for i in range(n, 0, -1): 
    	if res <= 0: 
    		break
        
    	# Either the result comes from the top (book[i-1][w]) or 
        # from (book[i-1][w-wt[i-1]] + values[i-1])
        # If it comes from the second, then item is included
        
    	if res == book[i - 1][w]: 
    		continue
    	else: 
    		print("Item: ", i, "\tWeight: ", weights[i-1]) 		
    		res = res - values[i - 1]     #weight included -> value decreased
    		w = w - weights[i - 1] 


def comptable(func, sheet):     #Simultaneously writes into excel sheet
	print("n  \tT(n)", end='\t')
	print("%11s\t%11s\t%11s\t%11s\t%11s" %("T(n)/log(n)", "T(n)/n", "T(n)/n^2", "T(n)/n^3", "2T(n)/2^n"))
	i=1
	for n in range(10,300,30):
		j=0	
		weights = random.sample(range(1, 1000), n)
		values =  random.sample(range(1, 1000), n)
		W= random.randint(1,500)
		book=[[0 for i in range(W+1)] for j in range(n)]

		totaltime=0
		for m in range(0, 100):
			start=time.time()
			func(n-1, W, weights, values, book)
			end=time.time()
			totaltime+=(end-start)
		avgtime=totaltime/100
		print("%3d  %.5f" %(n, avgtime), end='\t')

		sheet.write(i, j, n)
		j=j+1
		sheet.write(i, j, avgtime)
		j=j+1

		num=math.log(n)
		ratio=avgtime/num
		print("%.4e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1
		
		num=n
		ratio=avgtime/num
		print("%.4e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=n**2
		ratio=avgtime/num
		print("%.4e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=n**3
		ratio=avgtime/num
		print("%.4e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		num=2**n
		ratio=avgtime/num
		print("%.4e" %(avgtime/num), end='\t')
		sheet.write(i, j, num)
		j=j+1
		sheet.write(i, j, ratio)
		j=j+1

		print()
		i=i+1

def addSheetTitle(sheet):
	sheet.write(0, 0, "n")  
	sheet.write(0, 1, "T(n)")
	sheet.write(0, 2, "log(n)")
	sheet.write(0, 3, "T(n)/log(n)")
	sheet.write(0, 4, "n")
	sheet.write(0, 5, "T(n)/n")
	sheet.write(0, 6, "n^2")
	sheet.write(0, 7, "T(n)/n^2")
	sheet.write(0, 8, "n^3")
	sheet.write(0, 9, "T(n)/n^3")
	sheet.write(0, 10, "2^n")
	sheet.write(0, 11, "2T(n)/2^n")


n=4
weights=[2,1,3,2]
values=[12,10,20,15]
W=5

book=[[0 for i in range(W+1)] for j in range(n)]
res=knapsack(n-1, W, weights, values, book)
print("\nWeights : ", weights)
print("Values  : ", values)
print("\nValue of knapsack : ", res)
printSelected(res, book)

book.insert(0,[0 for i in range(W+1)])


print("\nbook")
for row in book:
	print(row)


print("\n\nEMPIRICAL ANALYSIS")
wb=Workbook()
sheet1=wb.add_sheet('Knapsack')

addSheetTitle(sheet1)

print("\n\nKnapsack: ")
comptable(knapsack, sheet1)
print()
