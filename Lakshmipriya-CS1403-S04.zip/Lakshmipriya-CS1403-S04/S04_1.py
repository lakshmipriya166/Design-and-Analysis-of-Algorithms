from Node import Node
from Point import Point
from Queue import LinkedQueue


def quicksort(l, refpoint):
	if len(l)<=1:
		return l
	left=[e for e in l[1:] if e.distance(refpoint) < l[0].distance(refpoint)]
	right=[e for e in l[1:] if e.distance(refpoint) >= l[0].distance(refpoint)]
	return quicksort(left, refpoint)+[l[0]]+quicksort(right, refpoint)


que=LinkedQueue()
n=int(input("Enter number of points: "))
for i in range(n):
	print("Point "+str(i+1)+" x,y : ",end='')
	x=[float(e) for e in input().split(",")]
	pt=Point(x[0],x[1])
	#print(pt.get_x())
	#print(pt.get_y())
	que.enqueue(pt)

x=[float(e) for e in input("Enter reference point x,y: ").split(",")]
refpoint=Point(x[0], x[1])

lst=[]

while(que.isEmpty()==False):
	lst.append(que.dequeue())


print("\nItems in list: ")
for i in lst:
	print(i)

sortedpoints=quicksort(lst, refpoint)


print("\nItems in SORTED list: ")
for i in sortedpoints:
	print(i)




