from Point import Point

def closepairs(lst, mindist):                                           # Let n=len(lst)
	for i in range(0, len(lst)-1):                                  # Complexity of i loop = O(n)
		for j in range(i+1, len(lst)):				# Complexity of j loop = O(n)
			if(lst[i].distance(lst[j])<mindist):
				print(str(lst[i])+" is closer to "+str(lst[j]))

'''
By Rule of Products,
	Complexity of algorithm = O(n)*O(n) = O(n^2)
'''


atms=[]
n=int(input("Enter number of ATMs: "))
for i in range(n):
	print("ATM "+str(i+1)+" coordinate x,y : ",end='')
	x=[float(e) for e in input().split(",")]
	atms.append(Point(x[0], x[1]))

print()
mindist=float(input("Enter minimum distance between 2 ATMs: "))
print("\nList of closer ATMs: ")
closepairs(atms, mindist)
