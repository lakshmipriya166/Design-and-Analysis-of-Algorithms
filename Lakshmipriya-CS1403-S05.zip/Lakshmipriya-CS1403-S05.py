import random

n=10
nuts = random.sample(range(0, 1000), n)
bolts = nuts[:]
random.shuffle(bolts)

print("\n\nUsing Brute Force: ")
print("\nAvailable components: ")
print("Nuts : ",nuts)
print("Bolts: ",bolts)

for i in range(len(nuts)):
	for j in range(len(bolts)):
		if (nuts[i]==bolts[j]):
			bolts[i], bolts[j] = bolts[j], bolts[i]
			break
print("\n\nMatched Pairs: ")
print("Nuts : ",nuts)
print("Bolts: ",bolts)



def nbsort(nuts, bolts):
    if(len(nuts) <= 0 or len(bolts) <= 0):
        return [],[]
    
    nutpivot = nuts[0]
    boltleft = []
    boltright = []
    boltequal = None

    for bolt in bolts:
        if bolt > nutpivot:
            boltright.append(bolt)
        elif bolt < nutpivot:
            boltleft.append(bolt)
        else:
            boltequal = bolt
    
    boltpivot = boltequal
    nutleft = []
    nutright = []
    
    for nut in nuts:
        if nut > boltpivot:
            nutright.append(nut)
        elif nut < boltpivot:
            nutleft.append(nut)

    nuts_arr = []
    bolts_arr = []

    lower_nuts, lower_bolts = nbsort(boltleft, nutleft)
    if(len(lower_nuts) > 0):
        for n in lower_nuts:
            nuts_arr.append(n)
        for b in lower_bolts:
            bolts_arr.append(b)
    
    nuts_arr.append(nutpivot)
    bolts_arr.append(boltequal) 

    upper_nuts, upper_bolts = nbsort(boltright, nutright)
    if(len(upper_nuts) > 0):
        for n in upper_nuts:
            nuts_arr.append(n)
        for b in upper_bolts:
            bolts_arr.append(b)
    
    return nuts_arr, bolts_arr


nuts = random.sample(range(0, 1000), n)
bolts = nuts[:]
random.shuffle(bolts)

print("\n\nUsing Quick sort: ")
print("\nAvailable components: ")
print("Nuts : ",nuts)
print("Bolts: ",bolts)

nuts, bolts=nbsort(nuts, bolts)

print("\n\nMatched Pairs: ")
print("Nuts : ",nuts)
print("Bolts: ",bolts)


