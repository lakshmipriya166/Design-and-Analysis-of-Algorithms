import math

class Node:
	def __init__(self, v1, v2, dist):
		self.v1 = v1
		self.v2 = v2
		self.dist = dist
        
	def __repr__(self):
		return str((self.v1, self.v2, self.dist))


def buildheap():                       #heap of Node(s)
	heap=[]
	heap.append(Node(-1, -1, -math.inf))   #sentinel for heap set
	return heap

parent=[]
        
def insertheap(heap, node):         #Node inserted into heap 
	heap.append(node)
	i=len(heap)-1
	while( i//2 > 0 ):
		parent=i//2
		if(heap[i].dist < heap[parent].dist):
			heap[i], heap[parent] = heap[parent], heap[i]
		else:
			break
		i=i//2

def deletemin(heap):                
	minval=heap[1]
	if(len(heap)==2):
	    return heap.pop()
	heap[1]=heap.pop()
	i=1
	while(2*i <= len(heap)-1):
		child=2*i
		if(child+1 < len(heap) and heap[child].dist > heap[child+1].dist):
			child += 1
		if(heap[i].dist > heap[child].dist):
			heap[i], heap[child] = heap[child], heap[i]
		else:
			break
		i=child
	return minval


def find(vertex):
	if(parent[vertex]<0):
		return vertex;
	else:
		parent[vertex] = find(parent[vertex])
		return parent[vertex]


def union(set1, set2):
	if(parent[set1] < parent[set2]):
		parent[set1] = -(-parent[set1]-parent[set2])
		parent[set2] = set1
	else:
		parent[set2] = -(-parent[set2]-parent[set1])
		parent[set1] = set2


def mstKruskal(n, edges, vertex):
	heap = buildheap()
	mindist = math.inf
	minindex = -1

	for i in range(0, len(edges)):
		v1=edges[i][0]
		v2=edges[i][1]
		dist=edges[i][2]
    
		heap.append(Node(v1, v2, dist))
        
		if(dist < mindist):
			mindist = dist
			minindex = i
		parent.append(-1)

	heap[1], heap[minindex+1] = heap[minindex+1], heap[1]
	count=0
	cost=0
	selected=[]

	while(count < len(vertex) and len(heap)>1):
		minNode = deletemin(heap)          
		tree1 = minNode.v1
		tree2 = minNode.v2
			
		set1 = find(tree1)
		set2 = find(tree2)

		if(set1 == set2 and set1!=-1):
			continue
		else:
			union(set1, set2)
			cost += minNode.dist
			selected.append([tree1, tree2, minNode.dist])

		count += 1
     
	if(count==len(vertex)-1):        
		print("\n\nSELECTED EDGES FOR MINIMUM SPANNING TREE: ")
		for sel in selected:
			print(vertex[sel[0]]," - ",vertex[sel[1]], " : ", sel[2])
    
		print("\nCOST OF SPANNING TREE : ",cost)

	else:
		print("MST consisting of all vertices not possible")
		

INF=math.inf


vertex = ["v1", "v2", "v3", "v4", "v5", "v6", "v7"]
n=len(vertex)

#[ [vertex1, vertex2, edge cost]...]

edges = [   [0, 1, 2], [0, 3, 1], 
            [1, 3, 3], [1, 4, 10], 
            [2, 0, 4], [2, 5, 5], 
            [3, 2, 2], [3, 4, 2], [3, 5, 8], [3, 6, 4],  
            [4, 6, 6],                 
            [6, 5, 1] 
        ]

heap=buildheap()

mstKruskal(n, edges, vertex)


'''
#[  [distance, pred, known, [[succ_vertex, weight]....] ], ...]
graph = [   [INF, -1, 0, [ [1, 2], [3, 1] ]                    ] , 
            [INF, -1, 0, [ [3, 3], [4,10] ]                    ] ,            
            [INF, -1, 0, [ [0, 4], [5, 5] ]                    ] ,            
            [INF, -1, 0, [ [2, 2], [4, 2], [5, 8], [6, 4] ]    ] ,            
            [INF, -1, 0, [ [6, 6] ]                            ] ,            
            [INF, -1, 0, [ ]                                   ] ,            
            [INF, -1, 0, [ [5, 1] ]                            ]
        ]
'''